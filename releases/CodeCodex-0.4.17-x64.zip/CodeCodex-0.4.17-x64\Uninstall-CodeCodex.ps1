[CmdletBinding()]
param(
    [switch]$KeepSettings,
    [switch]$PurgeSettings,
    [string]$InstallRoot
)

# storage-contract:start
# Shared install/uninstall location contract. No recursive operation follows a reparse point.
function Get-CodeCodexRegisteredRoot {
    $entry = Get-ItemProperty 'HKCU:\Software\CodeCodex' -ErrorAction SilentlyContinue
    if ($entry -and $entry.InstallPath) { return [string]$entry.InstallPath }
    $old = Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\CodeCodex' -ErrorAction SilentlyContinue
    if ($old -and $old.InstallLocation) { return [string]$old.InstallLocation }
    if ($entry -and $entry.RetainedRoot) { return [string]$entry.RetainedRoot }
    return Join-Path $env:LOCALAPPDATA 'Programs\Code-Codex'
}

function Assert-CodeCodexRoot([string]$Root, [switch]$Owned) {
    if ($Root -notmatch '^[A-Za-z]:[\\/]' -or $Root.Contains('"') -or $Root.Contains('..') -or $Root.Length -gt 180) {
        throw 'Choose a bounded absolute folder on a local drive (no network, relative or device paths).'
    }
    $full = [IO.Path]::GetFullPath($Root).TrimEnd('\', '/')
    if ($full.Length -le 3 -or $full.EndsWith('.') -or $full.EndsWith(' ')) { throw 'A drive root is not an application folder.' }
    foreach ($protected in @($env:USERPROFILE, $env:LOCALAPPDATA, $env:APPDATA, $env:WINDIR, $env:ProgramFiles, ${env:ProgramFiles(x86)}, [Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('MyDocuments'))) {
        if ($protected -and $full.Equals([IO.Path]::GetFullPath($protected).TrimEnd('\'), [StringComparison]::OrdinalIgnoreCase)) { throw 'Choose a dedicated Code-Codex folder, not a system or personal folder itself.' }
        if ($protected -and $protected -in @($env:WINDIR, $env:ProgramFiles, ${env:ProgramFiles(x86)}) -and $full.StartsWith($protected.TrimEnd('\')+'\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Choose a user-writable folder outside Windows and Program Files.' }
    }
    $drive = [IO.DriveInfo]::new([IO.Path]::GetPathRoot($full))
    if (-not $drive.IsReady -or $drive.DriveType -ne [IO.DriveType]::Fixed) { throw 'Installation requires an available fixed local drive.' }
    $cursor = $full
    while ($cursor) {
        $item = Get-Item -LiteralPath $cursor -Force -ErrorAction SilentlyContinue
        if ($item -and (-not $item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint))) { throw "Linked or non-directory storage ancestor refused: $cursor" }
        $cursor = Split-Path -Parent $cursor
    }
    if ($Owned) {
        $marker = Join-Path $full 'storage-layout.json'
        $item = Get-Item -LiteralPath $marker -Force -ErrorAction SilentlyContinue
        if ($item) {
            if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $item.Length -gt 4096) { throw 'Invalid or redirected storage marker; ownership refused.' }
            $layout = [IO.File]::ReadAllText($marker) | ConvertFrom-Json
            if ($layout.schema -eq 1 -and $layout.product -eq 'Code-Codex') { return $full }
            throw 'Unsupported storage marker; legacy ownership fallback refused.'
        }
        $legacy = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'Programs\Code-Codex'))
        $legacyMarker = Get-Item -LiteralPath (Join-Path $full 'install-type') -Force -ErrorAction SilentlyContinue
        if (-not $full.Equals($legacy,[StringComparison]::OrdinalIgnoreCase) -or -not $legacyMarker -or $legacyMarker.PSIsContainer -or ($legacyMarker.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Application ownership could not be verified; no files will be removed.' }
    }
    return $full
}

function Copy-CodeCodexDataTree([string]$Source, [string]$Destination) {
    $item = Get-Item -LiteralPath $Source -Force -ErrorAction SilentlyContinue
    if (-not $item) { return }
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Redirected migration source refused: $Source" }
    $existing = Get-Item -LiteralPath $Destination -Force -ErrorAction SilentlyContinue
    if ($existing -and ($existing.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw "Redirected migration destination refused: $Destination" }
    if ($item.PSIsContainer) {
        if ($existing -and -not $existing.PSIsContainer) { throw 'Migration destination has conflicting file type.' }
        New-Item -ItemType Directory -Path $Destination -Force | Out-Null
        foreach ($child in Get-ChildItem -LiteralPath $Source -Force) {
            Copy-CodeCodexDataTree $child.FullName (Join-Path $Destination $child.Name)
        }
    } else {
        if ($existing) {
            # Newer destination data wins. Keep the original source for recovery.
            $script:MigrationSkipped++
            return
        }
        New-Item -ItemType Directory -Path (Split-Path -Parent $Destination) -Force | Out-Null
        $stage = $Destination + '.' + [Guid]::NewGuid().ToString('N') + '.tmp'
        try {
            Copy-Item -LiteralPath $Source -Destination $stage
            if ((Get-FileHash -LiteralPath $Source -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath $stage -Algorithm SHA256).Hash) { throw 'Migrated resource hash mismatch.' }
            [IO.File]::Move($stage, $Destination)
            $script:MigrationCopied++
        } finally { if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Force } }
    }
}

function Measure-CodeCodexMigration([string]$Source, [string]$Destination) {
    $item = Get-Item -LiteralPath $Source -Force -ErrorAction SilentlyContinue
    if (-not $item) { return [long]0 }
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Redirected migration source refused: $Source" }
    if (-not $item.PSIsContainer) { if (Test-Path -LiteralPath $Destination) { return [long]0 }; return [long]$item.Length }
    [long]$size = 0
    foreach ($child in Get-ChildItem -LiteralPath $Source -Force) { $size += Measure-CodeCodexMigration $child.FullName (Join-Path $Destination $child.Name) }
    return $size
}

function Test-CodeCodexAtomicStorage([string]$Root, [scriptblock]$Progress = {param($phase,$status)}) {
    $full = Assert-CodeCodexRoot $Root
    if (-not (Test-Path -LiteralPath $full -PathType Container)) { throw 'Atomic storage probe requires an existing verified directory.' }
    $prefix = Join-Path $full ('.atomic-check-' + [Guid]::NewGuid().ToString('N'))
    $source = $prefix + '.source'; $target = $prefix + '.target'; $replacement = $prefix + '.replacement'; $backup = $prefix + '.backup'
    $phase = 'create'; $failure = $null; $cleanup = @()
    try {
        & $Progress $phase 'started'
        [IO.File]::WriteAllText($source,'probe-source')
        & $Progress $phase 'passed'
        $phase = 'rename'; & $Progress $phase 'started'
        [IO.File]::Move($source,$target)
        & $Progress $phase 'passed'
        $phase = 'replace'; & $Progress $phase 'started'
        [IO.File]::WriteAllText($replacement,'probe-replacement')
        [IO.File]::Replace($replacement,$target,$backup,$true)
        if ([IO.File]::ReadAllText($target) -ne 'probe-replacement') { throw 'Atomic replacement probe content mismatch.' }
        & $Progress $phase 'passed'
    } catch { $failure = $_; & $Progress $phase 'failed' }
    finally {
        foreach ($path in @($source,$target,$replacement,$backup)) {
            try {
                # Only these four exact task-created regular nodes are eligible.
                if ([IO.Path]::GetDirectoryName($path) -ne $full) { throw 'Probe cleanup path escaped its verified root.' }
                $item = Get-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue
                if ($item) {
                    if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Probe cleanup encountered a redirected node.' }
                    Remove-Item -LiteralPath $path -Force
                }
            } catch { $cleanup += $_.Exception.GetBaseException().Message }
        }
        & $Progress 'cleanup' $(if ($cleanup.Count) {'partial'} else {'passed'})
    }
    if ($failure) { throw [IO.IOException]::new(('Storage replacement preflight failed; phase='+$phase+'; cleanupIssues='+$cleanup.Count),$failure.Exception) }
    if ($cleanup.Count) { throw [IO.IOException]::new(('Storage probe cleanup failed: '+($cleanup -join '; '))) }
}

function Initialize-CodeCodexStorage([string]$Root) {
    $script:MigrationCopied = 0; $script:MigrationSkipped = 0
    [long]$required = 100MB
    $legacy = Join-Path $env:LOCALAPPDATA 'CodeCodex'
    foreach ($pair in @(@('settings.json','data\settings.json'),@('runtime-logs','logs\runtime'),@('diagnostics','logs\diagnostics'),@('plugin-cache\plugins','plugins'))) {
        $required += Measure-CodeCodexMigration (Join-Path $legacy $pair[0]) (Join-Path $Root $pair[1])
    }
    $previous = Get-ItemProperty 'HKCU:\Software\CodeCodex' -ErrorAction SilentlyContinue
    if ($previous -and $previous.RetainedRoot) {
        $previousRoot = Assert-CodeCodexRoot ([string]$previous.RetainedRoot) -Owned
        if (-not $Root.Equals($previousRoot,[StringComparison]::OrdinalIgnoreCase)) {
            foreach ($relative in @('data','plugins','logs','backups')) { $required += Measure-CodeCodexMigration (Join-Path $previousRoot $relative) (Join-Path $Root $relative) }
        }
    }
    $drive = [IO.DriveInfo]::new([IO.Path]::GetPathRoot($Root))
    if ($drive.AvailableFreeSpace -lt $required) { throw "Insufficient space for verified migration and installation: required=$required; available=$($drive.AvailableFreeSpace)." }
    foreach ($relative in @('data','plugins','logs\runtime','logs\diagnostics','logs\install','logs\update','temp','backups')) {
        $target = Join-Path $Root $relative
        $null = Assert-CodeCodexRoot $target
        New-Item -ItemType Directory -Path $target -Force | Out-Null
    }
    # Keep private preferences and diagnostic content private even on a shared data drive.
    foreach ($relative in @('data','logs','temp','backups')) {
        $target = Join-Path $Root $relative
        $acl = [IO.Directory]::GetAccessControl($target, [Security.AccessControl.AccessControlSections]::Access)
        $acl.SetAccessRuleProtection($true, $false)
        foreach ($existingRule in @($acl.Access)) { $null = $acl.RemoveAccessRuleSpecific($existingRule) }
        foreach ($sid in @([Security.Principal.WindowsIdentity]::GetCurrent().User, [Security.Principal.SecurityIdentifier]::new('S-1-5-18'), [Security.Principal.SecurityIdentifier]::new('S-1-5-32-544'))) {
            $rule = [Security.AccessControl.FileSystemAccessRule]::new($sid, 'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow')
            $acl.AddAccessRule($rule)
        }
        [IO.Directory]::SetAccessControl($target, $acl)
    }
    $registered = Get-ItemProperty 'HKCU:\Software\CodeCodex' -ErrorAction SilentlyContinue
    $retained = if ($registered) { [string]$registered.RetainedRoot } else { '' }
    if ($retained -and -not $Root.Equals($retained,[StringComparison]::OrdinalIgnoreCase)) {
        $retained = Assert-CodeCodexRoot $retained -Owned
        foreach ($relative in @('data','plugins','logs','backups')) {
            Copy-CodeCodexDataTree (Join-Path $retained $relative) (Join-Path $Root $relative)
        }
    }
    $old = Join-Path $env:LOCALAPPDATA 'CodeCodex'
    foreach ($pair in @(@('settings.json','data\settings.json'),@('runtime-logs','logs\runtime'),@('diagnostics','logs\diagnostics'))) {
        Copy-CodeCodexDataTree (Join-Path $old $pair[0]) (Join-Path $Root $pair[1])
    }
    $oldPlugins = Join-Path $old 'plugin-cache'
    if (Test-Path -LiteralPath $oldPlugins) {
        $null = Assert-CodeCodexRoot $oldPlugins
        foreach ($item in Get-ChildItem -LiteralPath $oldPlugins -Force) {
            if ($item.Name -eq 'plugins' -or $item.Name -match '^[a-z0-9-]+-[a-f0-9]{64}\.js$') {
                Copy-CodeCodexDataTree $item.FullName (Join-Path $Root $item.Name)
            }
        }
    }
    $report = [ordered]@{schema=1;copied=$script:MigrationCopied;preservedDestination=$script:MigrationSkipped;sourceRetained=$true;retainedRootMigrated=[bool]($retained -and -not $Root.Equals($retained,[StringComparison]::OrdinalIgnoreCase));completedAt=[DateTime]::UtcNow.ToString('o')}
    [IO.File]::WriteAllText((Join-Path $Root 'backups\legacy-migration.json'),($report|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
}

function Show-CodeCodexDirectoryChoice([string]$Initial, [bool]$Existing) {
    Add-Type -AssemblyName System.Windows.Forms
    $form = New-Object Windows.Forms.Form
    $form.Text='Code-Codex installation'; $form.Width=620; $form.Height=225
    $form.StartPosition='CenterScreen'; $form.FormBorderStyle='FixedDialog'; $form.MaximizeBox=$false; $form.MinimizeBox=$false; $form.TopMost=$true
    $label=New-Object Windows.Forms.Label; $label.Text=if($Existing){'Update in the existing folder. Settings, plugins and logs are preserved.'}else{'Choose one folder for Code-Codex, settings, plugins and logs.'}; $label.SetBounds(20,18,560,32); $form.Controls.Add($label)
    $box=New-Object Windows.Forms.TextBox; $box.Text=$Initial; $box.SetBounds(20,57,460,26); $box.ReadOnly=$Existing; $form.Controls.Add($box)
    $browse=New-Object Windows.Forms.Button; $browse.Text='Browse...'; $browse.SetBounds(488,55,90,30); $browse.Enabled=-not $Existing; $form.Controls.Add($browse)
    $browse.Add_Click({$dialog=New-Object Windows.Forms.FolderBrowserDialog; $dialog.Description='Select a parent folder. A dedicated Code-Codex subfolder will be created.'; if($dialog.ShowDialog() -eq 'OK'){$box.Text=Join-Path $dialog.SelectedPath 'Code-Codex'}; $dialog.Dispose()}.GetNewClosure())
    $note=New-Object Windows.Forms.Label; $note.Text='Default: current user installation on C: (no administrator rights required).'; $note.SetBounds(20,92,560,25); $form.Controls.Add($note)
    $ok=New-Object Windows.Forms.Button; $ok.Text=if($Existing){'Update'}else{'Install'}; $ok.SetBounds(388,130,90,32); $ok.DialogResult='OK'; $form.Controls.Add($ok); $form.AcceptButton=$ok
    $cancel=New-Object Windows.Forms.Button; $cancel.Text='Cancel'; $cancel.SetBounds(488,130,90,32); $cancel.DialogResult='Cancel'; $form.Controls.Add($cancel); $form.CancelButton=$cancel
    try { if($form.ShowDialog() -ne 'OK'){return $null}; return $box.Text } finally { $form.Dispose() }
}
# storage-contract:end

$ErrorActionPreference = "Stop"
if (-not $InstallRoot) { $InstallRoot = Get-CodeCodexRegisteredRoot }
$InstallFullPath = Assert-CodeCodexRoot $InstallRoot -Owned
$InstallPrefix = $InstallFullPath.TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
$ShortcutOwnerMarker = "Managed by Code-Codex (code-codex/v1)"
$LegacyShortcutDescription = "Launch Codex Desktop with Code-Codex file preview and editing"

function Publish-CodeCodexProgress([int]$Percent, [string]$Stage, [string]$Detail) {
    if ([string]::IsNullOrWhiteSpace($env:CLE_PROGRESS_STATE_PATH)) { return }
    try {
        $message = [Convert]::ToBase64String(
            [Text.Encoding]::UTF8.GetBytes($Stage + "`n" + $Detail)
        )
        $command = "{0}|progress|{1}|{2}" -f [DateTime]::UtcNow.Ticks, $Percent, $message
        [IO.File]::WriteAllText($env:CLE_PROGRESS_STATE_PATH, $command, [Text.UTF8Encoding]::new($false))
    }
    catch {} # A display failure must not interrupt uninstallation.
}

function Test-ReparsePoint([IO.FileSystemInfo]$Item) {
    return ($Item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0
}

function Get-ExistingItem([string]$Path) {
    return Get-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue
}

function Test-SamePath([string]$Left, [string]$Right) {
    if ([string]::IsNullOrWhiteSpace($Left) -or [string]::IsNullOrWhiteSpace($Right)) {
        return $false
    }
    try {
        $leftFull = [IO.Path]::GetFullPath($Left).TrimEnd(
            [IO.Path]::DirectorySeparatorChar,
            [IO.Path]::AltDirectorySeparatorChar
        )
        $rightFull = [IO.Path]::GetFullPath($Right).TrimEnd(
            [IO.Path]::DirectorySeparatorChar,
            [IO.Path]::AltDirectorySeparatorChar
        )
        return $leftFull.Equals($rightFull, [StringComparison]::OrdinalIgnoreCase)
    }
    catch {
        return $false
    }
}

function Test-SameProcessIdentity([object]$Expected, [object]$Current) {
    if ($null -eq $Expected -or $null -eq $Current -or
        $null -eq $Expected.CreationDate -or $null -eq $Current.CreationDate) {
        return $false
    }
    return [uint32]$Expected.ProcessId -eq [uint32]$Current.ProcessId -and
        [string]$Expected.Name -ieq [string]$Current.Name -and
        $Expected.CreationDate -eq $Current.CreationDate -and
        (Test-SamePath ([string]$Expected.ExecutablePath) ([string]$Current.ExecutablePath))
}

function Remove-ReparsePoint([IO.FileSystemInfo]$Item) {
    if ($Item.PSIsContainer) {
        [IO.Directory]::Delete($Item.FullName, $false)
    }
    else {
        [IO.File]::Delete($Item.FullName)
    }
}

function Remove-SettingsEntry([string]$Path, [switch]$RegularFileOnly) {
    $item = Get-ExistingItem $Path
    if ($null -eq $item) { return }
    if ($RegularFileOnly -and ((Test-ReparsePoint $item) -or $item.PSIsContainer)) {
        return
    }
    if (Test-ReparsePoint $item) {
        Remove-ReparsePoint $item
    }
    elseif ($item.PSIsContainer) {
        throw "Refusing to recursively remove an unexpected settings directory: $Path"
    }
    else {
        $item.Attributes = [IO.FileAttributes]::Normal
        [IO.File]::Delete($Path)
    }
}

function Remove-VerifiedCodeCodexDesktopShortcut {
    $desktop = [Environment]::GetEnvironmentVariable("CODE_CODEX_DESKTOP")
    if ([string]::IsNullOrWhiteSpace($desktop)) {
        $desktop = [Environment]::GetFolderPath([Environment+SpecialFolder]::DesktopDirectory)
    }
    if ([string]::IsNullOrWhiteSpace($desktop)) { return }

    $shortcutPath = Join-Path $desktop "Code-Codex.lnk"
    $shortcutItem = Get-ExistingItem $shortcutPath
    if ($null -eq $shortcutItem) { return }
    if ($shortcutItem.PSIsContainer -or (Test-ReparsePoint $shortcutItem)) { return }

    try {
        $shell = New-Object -ComObject WScript.Shell
        $shortcut = $shell.CreateShortcut($shortcutPath)
        $targetPath = [string]$shortcut.TargetPath
        $description = [string]$shortcut.Description
        if ([string]::IsNullOrWhiteSpace($targetPath)) { return }

        $targetFullPath = [IO.Path]::GetFullPath($targetPath)
        $expectedLauncher = Join-Path $InstallFullPath "CodeCodex.exe"
        $ownedTarget = (Test-SamePath $targetFullPath $expectedLauncher) -or
            $targetFullPath.StartsWith($InstallPrefix, [StringComparison]::OrdinalIgnoreCase)
        $ownedDescription = $description -eq $ShortcutOwnerMarker -or
            $description -eq $LegacyShortcutDescription

        if ($ownedTarget -and $ownedDescription) {
            $shortcutItem.Attributes = [IO.FileAttributes]::Normal
            [IO.File]::Delete($shortcutPath)
        }
    }
    catch {
        return
    }
}

if ($KeepSettings -and $PurgeSettings) {
    throw "-KeepSettings and -PurgeSettings cannot be used together."
}
Publish-CodeCodexProgress 18 "Checking installation" "Verifying the installation path and removal options."


$installItem = Get-ExistingItem $InstallFullPath
$processSnapshot = @()
$uninstallerLauncherPid = 0
$finalizerCopy = $null
$finalizerLaunched = $false
$powerShellPath = $null
if ($null -ne $installItem) {
    if (-not $installItem.PSIsContainer -or (Test-ReparsePoint $installItem)) {
        throw "Refusing to uninstall from a non-directory or reparse-point install path: $InstallFullPath"
    }
    $running = @()
    $unverifiedRunning = @()
    Publish-CodeCodexProgress 24 "Checking running processes" "Finding Code-Codex sessions that need to close."
    $processSnapshot = @(Get-CimInstance Win32_Process -ErrorAction Stop)
    foreach ($process in $processSnapshot) {
        $knownProductName = [string]$process.Name -in @(
            "code-codex.exe",
            "CodeCodex.exe"
        )
        if (-not $knownProductName) { continue }
        if ([string]::IsNullOrWhiteSpace([string]$process.ExecutablePath)) {
            $unverifiedRunning += [uint32]$process.ProcessId
            continue
        }
        try {
            $processPath = [IO.Path]::GetFullPath([string]$process.ExecutablePath)
            if ($processPath.StartsWith($InstallPrefix, [StringComparison]::OrdinalIgnoreCase)) {
                $running += [pscustomobject]@{
                    ProcessId = [uint32]$process.ProcessId
                    Name = [string]$process.Name
                    ExecutablePath = $processPath
                    CreationDate = $process.CreationDate
                }
            }
        }
        catch {
            $unverifiedRunning += [uint32]$process.ProcessId
        }
    }
    $unverifiedRunning = @($unverifiedRunning | Sort-Object -Unique)
    if ($unverifiedRunning.Count -gt 0) {
        $unverifiedProcessIds = $unverifiedRunning -join ", "
        throw "A running Code-Codex process could not be verified safely (process IDs: $unverifiedProcessIds). Close Code-Codex, then run the uninstaller again."
    }

    # Retain the process identities for the session launched by Code-Codex.
    # This includes the app server, package guard, and Codex window, but not an
    # unrelated Codex process whose parent chain is outside this launch.
    $ownedDescendants = @()
    $ownedProcessIds = @($running | ForEach-Object { [uint32]$_.ProcessId })
    $frontierProcessIds = @($ownedProcessIds)
    $descendantDepth = 1
    while ($frontierProcessIds.Count -gt 0 -and $descendantDepth -le 32) {
        $children = @(
            $processSnapshot |
                Where-Object {
                    [uint32]$_.ParentProcessId -in $frontierProcessIds -and
                    [uint32]$_.ProcessId -notin $ownedProcessIds
                }
        )
        if ($children.Count -eq 0) { break }

        foreach ($child in $children) {
            $childPath = $null
            if (-not [string]::IsNullOrWhiteSpace([string]$child.ExecutablePath)) {
                try {
                    $childPath = [IO.Path]::GetFullPath([string]$child.ExecutablePath)
                }
                catch {}
            }
            $ownedDescendants += [pscustomobject]@{
                ProcessId = [uint32]$child.ProcessId
                Name = [string]$child.Name
                ExecutablePath = $childPath
                CreationDate = $child.CreationDate
                Depth = $descendantDepth
            }
        }
        $frontierProcessIds = @($children | ForEach-Object { [uint32]$_.ProcessId })
        $ownedProcessIds += $frontierProcessIds
        $descendantDepth++
    }

    # A desktop user should not have to discover and close hidden launcher and
    # service processes before uninstalling. Stop only product executables that
    # are still verified inside this installation, checking the identity again
    # immediately before termination to narrow the PID-reuse race.
    $running = @(
        $running |
            Sort-Object `
                @{ Expression = { if ($_.Name -ieq "CodeCodex.exe") { 0 } else { 1 } } }, `
                ProcessId
    )
    Publish-CodeCodexProgress 31 "Closing Code-Codex" "Stopping verified Code-Codex processes before removal."
    $stoppedProcessIds = @()
    foreach ($runningProcess in $running) {
        $currentProcess = Get-CimInstance `
            Win32_Process `
            -Filter ("ProcessId = {0}" -f [uint32]$runningProcess.ProcessId) `
            -ErrorAction Stop
        if ($null -eq $currentProcess) { continue }

        if (-not (Test-SameProcessIdentity $runningProcess $currentProcess)) {
            # The launcher may have already closed this child. Never stop a
            # replacement process that reused the same PID.
            continue
        }

        try {
            Stop-Process -Id ([int]$runningProcess.ProcessId) -Force -ErrorAction Stop
        }
        catch {
            $stopError = $_.Exception.Message
            $afterStopFailure = Get-CimInstance `
                Win32_Process `
                -Filter ("ProcessId = {0}" -f [uint32]$runningProcess.ProcessId) `
                -ErrorAction Stop
            if (Test-SameProcessIdentity $runningProcess $afterStopFailure) {
                throw "Code-Codex could not be stopped automatically: $stopError"
            }
            continue
        }
        $stoppedProcessIds += [int]$runningProcess.ProcessId
    }
    $stoppedProcessIds = @($stoppedProcessIds | Sort-Object -Unique)
    if ($stoppedProcessIds.Count -gt 0) {
        Wait-Process -Id $stoppedProcessIds -Timeout 15 -ErrorAction SilentlyContinue
        $remaining = @(
            $running |
                Where-Object {
                    $_.ProcessId -in $stoppedProcessIds -and
                    (Test-SameProcessIdentity $_ (Get-CimInstance `
                        Win32_Process `
                        -Filter ("ProcessId = {0}" -f [uint32]$_.ProcessId) `
                        -ErrorAction Stop))
                }
        )
        if ($remaining.Count -gt 0) {
            throw "Code-Codex could not be stopped automatically. Restart Windows, then run the uninstaller again."
        }
    }

    # Stop the verified descendant session from the leaves inward. Closing the
    # Codex package processes lets the package guard exit, while leaving the
    # installed stable Codex application itself untouched on disk.
    $stoppedDescendantIds = @()
    foreach ($ownedDescendant in @(
        $ownedDescendants |
            Sort-Object `
                @{ Expression = { $_.Depth }; Descending = $true }, `
                ProcessId
    )) {
        $currentDescendant = Get-CimInstance `
            Win32_Process `
            -Filter ("ProcessId = {0}" -f [uint32]$ownedDescendant.ProcessId) `
            -ErrorAction Stop
        if ($null -eq $currentDescendant) { continue }
        if (-not (Test-SameProcessIdentity $ownedDescendant $currentDescendant)) {
            continue
        }

        try {
            Stop-Process -Id ([int]$ownedDescendant.ProcessId) -Force -ErrorAction Stop
            $stoppedDescendantIds += [int]$ownedDescendant.ProcessId
        }
        catch {
            $stopError = $_.Exception.Message
            $afterStopFailure = Get-CimInstance `
                Win32_Process `
                -Filter ("ProcessId = {0}" -f [uint32]$ownedDescendant.ProcessId) `
                -ErrorAction Stop
            if (Test-SameProcessIdentity $ownedDescendant $afterStopFailure) {
                throw "The Code-Codex session could not be closed automatically: $stopError"
            }
        }
    }
    $stoppedDescendantIds = @($stoppedDescendantIds | Sort-Object -Unique)
    if ($stoppedDescendantIds.Count -gt 0) {
        Wait-Process -Id $stoppedDescendantIds -Timeout 15 -ErrorAction SilentlyContinue
    }

    $processSnapshot = @(Get-CimInstance Win32_Process -ErrorAction Stop)

    $currentProcessRecord = $processSnapshot |
        Where-Object { [uint32]$_.ProcessId -eq [uint32]$PID } |
        Select-Object -First 1
    if ($null -ne $currentProcessRecord) {
        $parentProcessRecord = $processSnapshot |
            Where-Object {
                [uint32]$_.ProcessId -eq [uint32]$currentProcessRecord.ParentProcessId
            } |
            Select-Object -First 1
        if ($null -ne $parentProcessRecord -and
            [string]$parentProcessRecord.Name -ieq "Uninstall-CodeCodex.exe") {
            $expectedUninstaller = Join-Path $InstallFullPath "Uninstall-CodeCodex.exe"
            if ([string]::IsNullOrWhiteSpace([string]$parentProcessRecord.ExecutablePath) -or
                (Test-SamePath ([string]$parentProcessRecord.ExecutablePath) $expectedUninstaller)) {
                $uninstallerLauncherPid = [int]$parentProcessRecord.ProcessId
            }
        }
    }

    Publish-CodeCodexProgress 39 "Preparing file removal" "Verifying the separate removal helper."
    $finalizerSource = Join-Path $InstallFullPath "Finalize-Uninstall.ps1"
    $finalizerItem = Get-ExistingItem $finalizerSource
    if ($null -eq $finalizerItem) {
        throw "Uninstall finalizer is missing: $finalizerSource"
    }
    if ($finalizerItem.PSIsContainer -or (Test-ReparsePoint $finalizerItem)) {
        throw "Refusing to execute a non-file or reparse-point uninstall finalizer: $finalizerSource"
    }

    $systemDirectory = [Environment]::GetFolderPath([Environment+SpecialFolder]::System)
    $powerShellPath = [IO.Path]::GetFullPath((Join-Path $systemDirectory "WindowsPowerShell\v1.0\powershell.exe"))
    $systemDirectoryFull = [IO.Path]::GetFullPath($systemDirectory) + [IO.Path]::DirectorySeparatorChar
    $powerShellItem = Get-ExistingItem $powerShellPath
    if (-not $powerShellPath.StartsWith($systemDirectoryFull, [StringComparison]::OrdinalIgnoreCase) -or
        $null -eq $powerShellItem -or $powerShellItem.PSIsContainer -or
        (Test-ReparsePoint $powerShellItem)) {
        throw "Trusted Windows PowerShell executable was not found."
    }

    $finalizerCopy = Join-Path $env:TEMP ("CodeCodex-Uninstall-{0}.ps1" -f [Guid]::NewGuid().ToString("N"))
    try {
        Copy-Item -LiteralPath $finalizerSource -Destination $finalizerCopy
        $finalizerCopyItem = Get-ExistingItem $finalizerCopy
        if ($null -eq $finalizerCopyItem -or $finalizerCopyItem.PSIsContainer -or
            (Test-ReparsePoint $finalizerCopyItem) -or
            (Get-FileHash -LiteralPath $finalizerSource -Algorithm SHA256).Hash -ne
                (Get-FileHash -LiteralPath $finalizerCopy -Algorithm SHA256).Hash) {
            throw "The temporary uninstall finalizer could not be verified."
        }
    }
    catch {
        Remove-Item -LiteralPath $finalizerCopy -Force -ErrorAction SilentlyContinue
        throw
    }
}

if ($null -eq $installItem) {
    Write-Host "Code-Codex is not installed."
    return
}

try {
    # A physical uninstaller is also shipped by the MSI. Delegate from the
    # verified temporary helper so Windows Installer can remove this process.
    $installTypePath = Join-Path $InstallFullPath "install-type"
    $installTypeItem = Get-ExistingItem $installTypePath
    if ($null -ne $installTypeItem -and
        ($installTypeItem.PSIsContainer -or (Test-ReparsePoint $installTypeItem))) {
        throw "Refusing to read a non-file or reparse-point installation ownership marker: $installTypePath"
    }
    if ($null -ne $installTypeItem -and
        (Get-Content -LiteralPath $installTypePath -Raw -Encoding UTF8).Trim() -eq "msi") {
        Publish-CodeCodexProgress 48 "Handing off to Windows Installer" "The removal window will continue after this step closes."
        $msiProductCodePattern = '^\{[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\}$'
        $productCandidates = @(
            Get-ItemProperty `
                    "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*" `
                    -ErrorAction Stop |
                Where-Object {
                    $_.DisplayName -eq "Code-Codex" -and
                    [string]$_.PSChildName -match $msiProductCodePattern -and
                    [string]$_.WindowsInstaller -eq "1"
                }
        )
        $matchingProducts = @(
            $productCandidates |
                Where-Object { Test-SamePath ([string]$_.InstallLocation) $InstallFullPath }
        )
        if ($matchingProducts.Count -eq 0) {
            throw "The Windows Installer product registration for this install location could not be found."
        }
        if ($matchingProducts.Count -ne 1) {
            throw "Multiple Windows Installer product registrations refer to this install location; repair or remove the conflicting registrations before uninstalling."
        }
        $product = $matchingProducts[0]

        $delegateArguments = @(
            "-NoProfile",
            "-ExecutionPolicy", "Bypass",
            "-File", ('"{0}"' -f $finalizerCopy),
            "-InstallRoot", ('"{0}"' -f $InstallFullPath),
            "-ParentPid", $PID,
            "-MsiProductCode", ('"{0}"' -f [string]$product.PSChildName)
        )
        if ($uninstallerLauncherPid -gt 0) {
            $delegateArguments += @("-LauncherPid", $uninstallerLauncherPid)
        }
        if ($PurgeSettings) { $delegateArguments += "-PurgeSettings" }
        Start-Process -FilePath $powerShellPath -WindowStyle Hidden -ArgumentList $delegateArguments
        $finalizerLaunched = $true
        Write-Host "CODE_CODEX_UNINSTALL_DELEGATED"
        Write-Host "Windows Installer will remove Code-Codex after this window closes."
        return
    }

$shortcutTool = Join-Path $InstallFullPath "CodeCodex.Shortcut.exe"
Publish-CodeCodexProgress 45 "Restoring desktop shortcuts" "Removing Code-Codex links and restoring the official Codex shortcut."
$shortcutToolItem = Get-ExistingItem $shortcutTool
if ($null -eq $shortcutToolItem -or $shortcutToolItem.PSIsContainer -or (Test-ReparsePoint $shortcutToolItem)) {
    throw "The verified shortcut restoration tool is missing. No files were removed."
}
Remove-VerifiedCodeCodexDesktopShortcut
& $shortcutTool restore --install-root $InstallFullPath
if ($LASTEXITCODE -ne 0) {
    throw "The Codex, ChatGPT, or Code-Codex desktop shortcut could not be restored or removed. No Code-Codex files were removed."
}
Remove-VerifiedCodeCodexDesktopShortcut

Remove-ItemProperty `
    -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run" `
    -Name "CodeCodex" `
    -ErrorAction SilentlyContinue

if ($PurgeSettings) {
    Publish-CodeCodexProgress 49 "Cleaning settings" "Removing Code-Codex preferences selected for removal."
    $settingsRoot = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA "CodeCodex"))
    $allowedLocal = [IO.Path]::GetFullPath($env:LOCALAPPDATA) + [IO.Path]::DirectorySeparatorChar
    if (-not $settingsRoot.StartsWith($allowedLocal, [StringComparison]::OrdinalIgnoreCase)) {
        throw "Refusing to remove unexpected settings path: $settingsRoot"
    }
    $settingsItem = Get-ExistingItem $settingsRoot
    if ($null -ne $settingsItem) {
        if (-not $settingsItem.PSIsContainer) {
            throw "Refusing to remove a non-directory settings path: $settingsRoot"
        }
        if (Test-ReparsePoint $settingsItem) {
            Remove-ReparsePoint $settingsItem
        }
        else {
            foreach ($settingsName in @("settings.json", "settings.json.tmp")) {
                $settingsFile = Join-Path $settingsRoot $settingsName
                Remove-SettingsEntry $settingsFile
            }
            $crashOrphanPattern = [regex]::new(
                '^\.settings\.json\.[A-Za-z0-9]{16}\.tmp$',
                [Text.RegularExpressions.RegexOptions]::CultureInvariant
            )
            $crashOrphanPaths = @(
                [IO.Directory]::EnumerateFileSystemEntries(
                    $settingsRoot,
                    ".settings.json.*.tmp",
                    [IO.SearchOption]::TopDirectoryOnly
                ) | Select-Object -First 64
            )
            foreach ($crashOrphanPath in $crashOrphanPaths) {
                if ($crashOrphanPattern.IsMatch([IO.Path]::GetFileName($crashOrphanPath))) {
                    Remove-SettingsEntry $crashOrphanPath -RegularFileOnly
                }
            }
            $verifiedSettings = Get-ExistingItem $settingsRoot
            if ($null -ne $verifiedSettings -and
                -not (Test-ReparsePoint $verifiedSettings) -and
                $verifiedSettings.PSIsContainer -and
                @(Get-ChildItem -LiteralPath $settingsRoot -Force).Count -eq 0) {
                [IO.Directory]::Delete($settingsRoot, $false)
            }
        }
    }
}

$finalizerArguments = @(
    "-NoProfile",
    "-ExecutionPolicy", "Bypass",
    "-File", ('"{0}"' -f $finalizerCopy),
    "-InstallRoot", ('"{0}"' -f $InstallFullPath),
    "-ParentPid", $PID
)
if ($PurgeSettings) { $finalizerArguments += '-PurgeSettings' }
if ($uninstallerLauncherPid -gt 0) {
    $finalizerArguments += @("-LauncherPid", $uninstallerLauncherPid)
}
Start-Process -FilePath $powerShellPath -WindowStyle Hidden -ArgumentList $finalizerArguments
$finalizerLaunched = $true
Publish-CodeCodexProgress 54 "Handing off file removal" "The removal window will continue after this step closes."
Write-Host "CODE_CODEX_UNINSTALL_DELEGATED"

Write-Host "The Codex or ChatGPT desktop shortcut was restored, or the Code-Codex shortcut was removed. Code-Codex will be removed after this window closes."
}
catch {
    if (-not $finalizerLaunched -and
        -not [string]::IsNullOrWhiteSpace([string]$finalizerCopy)) {
        Remove-Item -LiteralPath $finalizerCopy -Force -ErrorAction SilentlyContinue
    }
    throw
}
